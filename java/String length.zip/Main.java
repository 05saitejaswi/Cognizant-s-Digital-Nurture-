import java.util.Scanner;
import java.io.*;
public class Main {

    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        // Fill the code
        String s = sc.nextLine();
        int n = s.length();
        if(n%2==0){
            System.out.println(n + " Even");
        }
        else {
            System.out.println(n + " Odd");
        }
    }

}

