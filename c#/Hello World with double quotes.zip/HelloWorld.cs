using System;

namespace HelloWorldApplication {
   
   class HelloWorld {

      static void Main(string[] args) {
         Console.WriteLine("\"Hello World\"");
         Console.ReadKey();
      }
   }
}