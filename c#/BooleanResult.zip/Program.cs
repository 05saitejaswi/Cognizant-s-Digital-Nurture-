using System;
public class Program{
    static void Main(string[] args)
    {
        int x,y;
        bool result=false;
        Console.WriteLine("Enter the value for x");
        x=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the value for y");
        y=Convert.ToInt32(Console.ReadLine());
        if(x<y)
            result=true;
            Console.WriteLine("x is less than y is " + result);
    }
}