using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals7                 //DO NOT CHANGE the name of namespace
{
    public class Program                    //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)      //DO NOT CHANGE 'Main' Signature
        {
        //Implement your code here
        Console.WriteLine("Enter the name of the product:");
        string prodname=Console.ReadLine();
        Console.WriteLine("Enter the price of the product:");
        decimal price=Convert.ToDecimal(Console.ReadLine());
        
        Console.WriteLine("Is the product on SALE(yes/no):");
        string sale=Console.ReadLine();
        decimal tot=0;
        decimal[] arr=new decimal[100];
        if(sale=="yes")
        {
        for(int i=0;i<3;i++)
        {
        
            Console.WriteLine("Enter number of product sold in day "+(i+1));
            int noofprod= Convert.ToInt32(Console.ReadLine());
            price=price- (price* 7/100);
            tot=0;
            for(int j=0;j<noofprod;j++)
            {
                tot=tot+price;
        
            }
            arr[i]=Math.Floor(tot);
        }
        Console.WriteLine(prodname);
        for(int i=0;i<3;i++)
        {
            Console.WriteLine("Day "+(i+1)+" sales total : "+arr[i]);
        }
        }
        else if(sale=="no")
        {
            for(int i=0;i<3;i++)
            {
                Console.WriteLine("Enter number of product sold in day "+(i+1));
                int noofprod=Convert.ToInt32(Console.ReadLine());
               
                    tot=price*noofprod;
                
                arr[i]=tot;
            }
            Console.WriteLine(prodname);
            for(int i=0;i<3;i++)
            {
                Console.WriteLine("Day "+(i+1)+" sales total : "+arr[i]);
            }
        }
        }
    }
}


