using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals12                 //DO NOT CHANGE the name of namespace
{
    public class Program                    //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)   //DO NOT CHANGE 'Main' Signature
        {
           
           // Fill the code here
           int i,j,k;
           Console.WriteLine("Number of Rows : ");
           int n1=Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Number of Symbols :");
           int n2=Convert.ToInt32(Console.ReadLine());
           for(i=1;i<=n1;i++)
           {
               for(j=1;j<=n2;j++)
               {
                   Console.Write("/\\");
                   
               }
               Console.WriteLine("");
               for(k=1;k<=(n2*2);k++)
               {
                   if(k==1 || k==(n2*2))
                   {
                       Console.Write("|");
                       
                       continue;
                   }
                  
                   else 
                   {
                       Console.Write(" ");
                       
                       continue;
                   }
                   
               }
               Console.WriteLine("");
               
               
           }
           
        }
    }
}


