using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals4              //DO NOT CHANGE the name of namespace
{
    public class Program                 //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)   //DO NOT CHANGE 'Main' Signature
        {
            int i,j;
            Console.WriteLine("Enter any alphabet ");
            //Get the value
            char ch=Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Enter number of repeats : ");
            //Get the value
            int n=Convert.ToInt32(Console.ReadLine());
            
            //Implement your code here
            for(i=1;i<=n;i=i+2)
            {
                for(j=i;j<n;j++)
                {
                    Console.Write(" ");
                }
                for(int k=1;k<=i;k++)
                {
                    Console.Write(ch);
                }
                Console.WriteLine("");
            }

        }
    }
}

