using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals9             //DO NOT CHANGE the name of namespace
{
    public class Program                //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)      //DO NOT CHANGE 'Main' Signature
        {
           
           // Fill the code here
           String[] name=new String[100];
           String[] place=new String[100];
           char[] status=new char[100];
           char wish;
           int i,count=1;
           for(i=0;;i++)
           {
                Console.Write("Enter Name : ");
                name[i]=Console.ReadLine();
                Console.Write("Enter Place : ");
                place[i]=Console.ReadLine();
                Console.Write("Enter marital status(y/n) : ");
                status[i]=Convert.ToChar(Console.ReadLine());
                Console.Write("Do you wish to continue(y/n) : ");
                wish=Convert.ToChar(Console.ReadLine());
                if(wish=='y')
                {
                    continue;
                    count++;
                }
                else
                {
                    break;
                }
           }
           for(i=0;i<=count;i++)
           {
                Console.WriteLine("Confirming Information");
                Console.WriteLine(name[i]);
                Console.WriteLine(place[i]);
                Console.WriteLine("Married : "+status[i]);
           }
        }
    }
}


