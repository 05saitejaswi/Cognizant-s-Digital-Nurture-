using System;

public class Program   //DO NOT change the class name
{
    static void Main(string[] args)       //DO NOT change the 'Main' method signature
    {
        //Fill code here
        Console.WriteLine("Enter a number:");
        int n=Convert.ToInt32(Console.ReadLine());
        int[,] arr1=new int[n,n];
        arr1=GetArray(n);
        for(int i=0;i<n;i++)
        {
            Console.Write("\n");
            for(int j=0;j<n;j++)
            {
                Console.Write("{0}\t",arr1[i,j]);
            }
        }
        Console.Write("\n\n");
    }
    
    public static int[,]  GetArray(int num)
    {
        //Fill code here  
        int i,j;
        int[,] arr1=new int[num,num];
        for( i=0;i<num;i++)
        {
            for(j=0;j<num;j++)
            {
                if(i<j)
                {
                    arr1[i,j]=1;
                }
                else if(i>j)
                {
                    arr1[i,j]=-1;
                }
                else
                {
                   arr1[i,j]=0;
                }
            }
        }
        return arr1;
    }
}    
    
