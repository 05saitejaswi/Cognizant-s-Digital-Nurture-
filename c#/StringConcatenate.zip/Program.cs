using System;
  
public class GFG {
      
  
    static public void Main()
    {
       
        Console.WriteLine("\"Enter first name");
        string strA=Console.ReadLine();
        Console.WriteLine("Enter last name");
        string strB=Console.ReadLine();
        string str;

        str = String.Concat(strA," ",strB);
  
        Console.WriteLine("Full name : {0}", str);
    }
}