using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals3             //DO NOT CHANGE the name of namespace
{
    public class Program                 //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)       //DO NOT CHANGE 'Main' Signature
        {
           
           //Fill the code here
          string word="casablanca";
          char[] ch=new char[word.Length];
          char[] s=word.ToCharArray();
         
          for (int i=0;i<word.Length;i++)
          {
              ch[i]=word[i];
          }
          for(int i=0;i<word.Length;i++)
          {
              Console.Write("Enter letter "+(i+1)+" : ");
              s[i]=Convert.ToChar(Console.ReadLine());
          }
          for(int i=0;i<word.Length;i++)
          {
              Console.Write("Enter letter "+(i+1)+" : ");
              Console.WriteLine(s[i]);
               if(ch[i]!=s[i])
              {
                   Console.WriteLine("The spelling is wrong");
               }
          }
        }
    }
}

