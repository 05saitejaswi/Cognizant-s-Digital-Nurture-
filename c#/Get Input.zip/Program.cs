using System;
public class Program{
    static public void Main()
    {
        Console.WriteLine("Enter your first name");
        string strA=Console.ReadLine();
        Console.WriteLine("Enter your last name");
        string strB=Console.ReadLine();
        string str;
        str=String.Concat(strA," ",strB);
        Console.WriteLine("Your full name is {0}",str);
    }
}