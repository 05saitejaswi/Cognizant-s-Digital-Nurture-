using System;
using System.IO;

public class Person
{
    //Fill code here
    private String firstName;
    private String lastName;
    private DateTime dob;
    
    public String FirstName 
    {
        get { return firstName;
        }
        set{
            firstName=value;
        }
    }
    public String LastName 
    {
        get{
            return lastName;
        }
        set{
            lastName=value;
        }
    }
    public DateTime Dob 
    {
        get{
            return dob;
        }
        set{
            dob=value;
        }
    }
    
    public int GetAge(DateTime dob)
    {
   DateTime Now=DateTime.Now;
   int age=0;
   age=DateTime.Now.Year-dob.Year;
   if(DateTime.Now.DayOfYear< dob.DayOfYear)
   {
       age=age-1;
   }
   return age;
    
    }
    public String Adult
    {
        get 
        {
            if(GetAge(dob)<18)
              return "Child";
             else
               return "Adult";
        }
        
    }
    public void DisplayDetails()
    {
        Console.WriteLine("First Name: "+FirstName);
        Console.WriteLine("Last Name: "+LastName);
        Console.WriteLine("Age: "+GetAge(dob));
        Console.WriteLine(Adult);
        
    }
}

public class Progarm
{
    public static void Main(String[] args)
    {
        //Fill code here    
        Person p=new Person();
        Console.WriteLine("Enter first name");
        p.FirstName=Console.ReadLine();
        Console.WriteLine("Enter last name");
        p.LastName=Console.ReadLine();
        Console.WriteLine("Enter date of birth in yyyy/mm/dd format");
        p.Dob=DateTime.Parse(Console.ReadLine());
        p.DisplayDetails();
    }
}

