using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals5              //DO NOT CHANGE the name of namespace
{
    public class Program                //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)        //DO NOT CHANGE 'Main' Signature
        {
            //Implement your code here
            Console.WriteLine("Enter English marks : ");
            int e=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Math marks :");
            int m=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Language marks :");
            int l=Convert.ToInt32(Console.ReadLine());
            if(e>0 && m>0 && l>0)
            {
           
             if(e>=80 && e<=100)
            {
                Console.WriteLine("English Grade : A+");
                
            }
            else if(e>=60 && e<80)
            {
                Console.WriteLine("English Grade : A");
            }
            else if(e>=40 && e<60)
            {
                Console.WriteLine("English Grade : B");
            }
            else if(e<40)
            {
                Console.WriteLine("English Grade : FAIL");
            }
        
            //Console.WriteLine("Enter Language marks : ");
            //int l=Convert.ToInt32(Console.ReadLine());
            
           
             if(m>=80 && m<=100)
            {
                Console.WriteLine("Math Grade : A+");
            }
            else if(m>=60 && m<80)
            {
                Console.WriteLine("Math Grade : A");
                
            }
            else if(m>=40 && m<60)
            {
                Console.WriteLine("Math Grade : B");
            }
            else if(m<40)
            {
                Console.WriteLine("Math Grade : FAIL");
            }
           
             if(l>=80 && l<=100)
            {
                Console.WriteLine("Language Grade : A+");
                
            }
            else if(l>=60 && l<80)
            {
                Console.WriteLine("Language Grade : A");
            }
            else if(l>=40 && l<60)
            {
                Console.WriteLine("Language Grade : B");
            }
            else if(l<40)
            {
                Console.WriteLine("Language Grade : FAIL");
            }
            }
            else
            {
                Console.WriteLine("Mark cannot be less than 0");
            }
        }
    }
}

