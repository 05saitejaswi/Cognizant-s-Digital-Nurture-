using System;
public class Prgogram
{
    static void Main(string[] args){
        string str,result="";
        Console.WriteLine("Enter a string");
        str=Console.ReadLine();
        string[] strarr=str.Split();
        for(int i=strarr.Length-1;i>=0;i--)
        {
            result+=strarr[i]+" ";
        }
        Console.WriteLine(result);
    }
}