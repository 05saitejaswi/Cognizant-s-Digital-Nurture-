using System;
using System.Text;
public class Program{
    static void Main(string[] args){
        string name,city;
        float age;
        char gender;
        long mobile,pin;
        Console.WriteLine("Enter name");
        name=Console.ReadLine();
        Console.WriteLine("Enter age(completed years and months)");
        age=float.Parse(Console.ReadLine());
        Console.WriteLine("Enter gender('M' for Male and 'F' for Female)");
        gender=Console.ReadLine()[0];
        Console.WriteLine("Enter city");
        city=Console.ReadLine();
        Console.WriteLine("Enter mobile number");
        mobile=Convert.ToInt64(Console.ReadLine());
        Console.WriteLine("Enter pincode");
        pin=Convert.ToInt64(Console.ReadLine());
        Console.WriteLine("Name:"+"  "+name);
        Console.WriteLine("Age:"+"  "+age);
        Console.WriteLine("Gender:"+"  "+gender);
        Console.WriteLine("City:"+" "+city);
        Console.WriteLine("Mobile:"+" "+mobile);
        Console.WriteLine("Pincode:"+" "+pin);
    }
}