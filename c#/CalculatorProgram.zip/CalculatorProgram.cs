using System;
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the operator");
        string sign=Console.ReadLine();
        Console.WriteLine("Enter the operands");
        int a=Convert.ToInt32(Console.ReadLine());
        int b=Convert.ToInt32(Console.ReadLine());
        CalculatorProgram cal=new CalculatorProgram();
        switch(sign)
        {
            case "+":
                Console.WriteLine("Result of "+a+" + "+b+" is "+cal.Addition(a,b));
                break;
            case "-":
                Console.WriteLine("Result of "+a+" - "+b+" is "+cal.Subtraction(a,b));
                break;
            case "*":
                Console.WriteLine("Result of "+a+" * "+b+" is "+cal.Multiplication(a,b));
                break;
            case "/":
                Console.WriteLine("Result of "+a+" / "+b+" is "+cal.Division(a,b,out double remainder));
                Console.WriteLine($"Remainder ={remainder}");
                break;
            default :
                Console.WriteLine("Invalid Operator");
                break;
        }
    }
}
public class CalculatorProgram
{
    public int Addition(int a,int b)
    {
        return a+b;
        
    }
    public int Subtraction(int a,int b)
    {
        return a-b;
    }
    public int Multiplication(int a,int b)
    {
        return a*b;
    }
    public double Division(int a,int b,out double remainder)
    {
        remainder=a%b;
        return a/b;
    }
}
