select Subject.subject_name,Subject_code,Staff.staff_name
from Subject  inner join Staff on Subject.staff_id=Staff.staff_id
order by subject_code ASC;