create view customer_mobile_details as
select c.customer_ID, c.customer_name, c.mobile, s.salesId, s.net_amount,
m.model_name, m.manufacturer
from( customer_info c inner join sales_info s
on c.customer_ID=s.customer_ID) inner join
mobile_master m 
on m.ime_no=s.ime_no
order by c.customer_ID, c.customer_name, s.salesId;